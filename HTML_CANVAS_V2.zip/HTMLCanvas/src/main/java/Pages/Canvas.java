package Pages;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import BaseClass.BaseClass;

public class Canvas extends BaseClass {

	@FindBy(xpath = "//input[@class='button line']")
	WebElement DrawLineButton;
	@FindBy(xpath = "//canvas[@id='imageTemp']")
	WebElement canvaswindow;
	@FindBy(xpath = "//input[@class='button line clicked']")
	WebElement DrawLineButtonClicked;

	public Canvas() {
		PageFactory.initElements(driver, this);
	}

	public void ClickDrawLine() {
		DrawLineButton.click();
	}

	public void RobotMove(int x, int y) {

		try {
			Robot r = new Robot();
			r.mouseMove(x, y);
		} catch (AWTException e) {
			e.printStackTrace();
		}

	}

	public void RobotClick() {

		try {
			Robot r = new Robot();
			r.mousePress(InputEvent.BUTTON1_DOWN_MASK);

		} catch (AWTException e) {
			e.printStackTrace();
		}

	}

	public void RobotRelease() {

		try {
			Robot r = new Robot();
			r.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
		} catch (AWTException e) {
			e.printStackTrace();
		}

	}

	

}
