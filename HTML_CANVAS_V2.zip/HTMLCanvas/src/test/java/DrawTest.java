import org.openqa.selenium.WebElement;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;



import BaseClass.BaseClass;
import Pages.Canvas;

public class DrawTest extends BaseClass {
	Canvas canvas;
	 
	
public DrawTest() {
		
	super()	;
	}
	
@BeforeMethod

public void Initilizing() {
	
	 Inialize();
	 canvas=new Canvas();
	 canvas.ClickDrawLine();
}

@Test
public void DrawVTest(){
	
	
	
	//For Vertical Line
	canvas.RobotMove(400,315);// x++-->/x-- -->left and y starts from ~315 of vertical line  starting
	canvas.RobotClick();
	canvas.RobotRelease();
	canvas.RobotMove(400,650); // x and y of vertical line ending
	canvas.RobotClick();
	canvas.RobotRelease();
	
	//For Horizontal line
	canvas.RobotMove(765,360); //Staring from left x ~ 765
	canvas.RobotClick();
	canvas.RobotRelease();
	canvas.RobotMove(175,360); //minimum ~175
	canvas.RobotClick();
	canvas.RobotRelease();
	
}

}
